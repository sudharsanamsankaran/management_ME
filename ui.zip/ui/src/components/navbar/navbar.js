import React from "react";
import {
    BrowserRouter as Router,
    Routes,
    Route,
    Link
} from "react-router-dom";
import GetCount from "../dashboard/fetchtaskleader";
import GetCountAssociate from '../dashboard/fetchtaskassocitate';
import Login from "../login/login";
import LeaderReport from "../report/leaderreport";
import CreateUser from "../newuser/createuser";
import Taskassign from "../taskassign/taskassign";
import Userdata from "../dashboard/userdata";
import '../navbar.css'


export default function Sidenavbar() {
    return (
        <Router>
            <>
                <div className="nav">
                    <div>
                        <Userdata />
                    </div>
                    <nav>
                        <ul>
                            <li>
                                <Link to="/">Logout</Link>
                            </li>
                        </ul>
                    </nav>
                </div>

            </>

            <div className="display">
                <Routes>
                    <Route path="associatedashboard" element={<Login><GetCountAssociate /></Login>}>
                    </Route>
                    <Route path="associatereport" element={<Login><LeaderReport /></Login>}>
                    </Route>
                    <Route path="/leader/*" element={<Login><GetCount /></Login>}>
                    </Route>
                    <Route path="leadreport" element={<Login><LeaderReport /></Login>}>
                    </Route>
                    <Route path="createuser" element={<Login><CreateUser /></Login>}>
                    </Route>
                    <Route path="assigntask" element={<Login><Taskassign /></Login>}>
                    </Route>
                    <Route path="/" element={<Login />}>
                    </Route>
                </Routes>
            </div>
        </Router>
    );
}


