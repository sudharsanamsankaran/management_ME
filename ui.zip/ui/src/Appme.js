import React from "react";
//import Teamlead from "./components/teamlead";
import Sidenavbar from "./components/navbar/navbar";

export default function App() {
  return (
    <div>
      <div><h1>ManageUS</h1></div>
      <Sidenavbar/>
      {/* <Teamlead/> */}
    </div>
    
  );
}


