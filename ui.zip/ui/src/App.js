// import React from "react";
// import Associatesidenavbar from "./components/associatesidenavbar/associateSidenavbar";
// import LeaderSidenavbar from "./components/leadersidenavbar/leaderSidenavbar";


// export default function App() {
//   return (
//     <div>
//       <div><h1>ManageUS</h1></div>
//       <LeaderSidenavbar/>
//        <Associatesidenavbar/>
//     </div>
    
//   );
// }

import Associatesidenavbar from "./components/associatesidenavbar/associateSidenavbar";
// import LeaderSidenavbar from "./components/leadersidenavbar/leaderSidenavbar";



// <div>

//   <LeaderSidenavbar/>
//   {/* <Associatesidenavbar/> */}
// </div>



import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  //Link
} from "react-router-dom";
//import Login from "./components/login/login"
//import Teamlead from "./components/teamlead";
import GetCount from "./components/dashboard/fetchtaskleader";
import Login from "./components/login/login";
import LeaderReport from "./components/report/leaderreport";
//import CreateUser from "../newuser/createuser";
import Taskassign from "./components/taskassign/taskassign";
//import Userdata from "../dashboard/userdata";
import Register from "./components/newuser/createuser";
import "../src/components/navbar.css"
import LeaderSidenavbar from "./components/leadersidenavbar/leaderSidenavbar";
export default function App() {
  return (
    <div> 
        <Router>
           

            
                <Routes>

                    
                    <Route path="/" element={<Login />}>
                    </Route>
                    {/* <Route path="/*" element={<LeaderSidenavbar/>}>
                    </Route> */}
                    {/* <Route path="/leaderdashboard" element={<GetCount/>}> */}
                    <Route path="/leader/*" element={<LeaderSidenavbar/>}>
                    {/* {/* <Route path="/leaddashboard" element={<GetCount />}>
                    </Route> */}
                    {/* <Route path="/leaderreport/*" element={<LeaderReport />}>
                    </Route> */}
                    {/* <Route path="/createuser" element={<Register />}>
                    </Route> */}
                    {/* <Route path="/assigntask" element={<Taskassign />}>
                    </Route> */} 
                    </Route>
                    
                    <Route path="/associate/*" element={<Associatesidenavbar />}>
              
                    </Route>
                  
                </Routes>
            
        </Router>
        </div>
  );
}





